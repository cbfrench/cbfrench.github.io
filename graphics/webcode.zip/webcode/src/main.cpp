/* Lab 6 base code - transforms using matrix stack built on glm
 * CPE 471 Cal Poly Z. Wood + S. Sueda + I. Dunn
 */

#include <iostream>
#include <glad/glad.h>
#include <math.h>

#include "GLSL.h"
#include "Program.h"
#include "Shape.h"
#include "MatrixStack.h"
#include "WindowManager.h"

// value_ptr for glm
#include <glm/gtc/type_ptr.hpp>
#include <glm/gtc/matrix_transform.hpp>

using namespace std;
using namespace glm;

typedef struct position {
	vec2 p1;
	vec2 p2;
} Position;

class Application : public EventCallbacks
{

public:

	WindowManager * windowManager = nullptr;

	// Our shader program
	std::shared_ptr<Program> prog;
	std::shared_ptr<Program> groundProg;

	// Shape to be used (from obj file)
	shared_ptr<Shape> shape;
	shared_ptr<Shape> circle;

	// Contains vertex information for OpenGL
	GLuint VertexArrayID;

	// Data necessary to give our triangle to OpenGL
	GLuint VertexBufferID;

	/*
	---------------------------------------------------------
	---------------------CONTROL VARIABLES-------------------
	---------------------------------------------------------
	*/
	//position variables
	float X_DIR = 0, Y_DIR = 0, Z_DIR = 0;

	//animation variables
	float ANIMATION_ANGLE;
	float ARM_ANGLE = 0;
	bool ANIMATION_DIRECTION = false;

	//mathematical constants
	float PI = 3.1415926;
	float STAGE = -25;
	float EARTH_SCALE = 20.0;
	float PLAYER_HEIGHT = 3 + EARTH_SCALE;
	float ROTATION_INCREMENT = 0.25;
	float NEXT_PLAT = 1;
	float PLAT_HEIGHT = 0;
	float NEW_HEIGHT = 0;
	float GRAVITY = 0.05;

	//camera variables
	float CAMERA = -50.0;
	float CAM_ANIM = 0.50;
	float Y_HEIGHT = 10;

	//platform variables
	float GROUND = 50.0;
	float GAP_WIDTH = 32;
	float TOTAL_GAP_WIDTH = 0;
	int PLAT_NUM = 50;
	float RANDOMS[50];
	float GAPS[50];

	//player status variables
	float WALK_SPEED = 16.0;
	float RUN_SPEED = 32.0;
	float SPEED = WALK_SPEED;
	float DIRECTION = 0;
	bool LEFT = false;
	bool RIGHT = false;
	bool JUMP = false;
	bool RUNNING = false;
	bool GROUNDED = true;
	float JUMP_STRENGTH = 1.25;
	float JUMP_VELOCITY = JUMP_STRENGTH;
	float FALL_VELOCITY = -GRAVITY;


	void keyCallback(GLFWwindow *window, int key, int scancode, int action, int mods)
	{
		if (key == GLFW_KEY_ESCAPE && action == GLFW_PRESS)
		{
			glfwSetWindowShouldClose(window, GL_TRUE);
		}
		if((key == GLFW_KEY_A || key == GLFW_KEY_LEFT) && action == GLFW_PRESS)
		{
			LEFT = true;
		}
		if ((key == GLFW_KEY_A || key == GLFW_KEY_D || key == GLFW_KEY_LEFT || key == GLFW_KEY_RIGHT) && action == GLFW_RELEASE) {
			ANIMATION_ANGLE = 0;
			ANIMATION_DIRECTION = false;
			LEFT = false;
			RIGHT = false;
		}
		if ((key == GLFW_KEY_D || key == GLFW_KEY_RIGHT) && action == GLFW_PRESS) {
			RIGHT = true;
		}
		if (key == GLFW_KEY_SPACE || key == GLFW_KEY_W || key == GLFW_KEY_UP)
		{
			JUMP = true;
		}
		if ((key == GLFW_KEY_LEFT_SHIFT || key == GLFW_KEY_RIGHT_SHIFT) && action == GLFW_PRESS) {
			RUNNING = true;
		}
		if ((key == GLFW_KEY_LEFT_SHIFT || key == GLFW_KEY_RIGHT_SHIFT) && action == GLFW_RELEASE) {
			RUNNING = false;
		}
	}

	void mouseCallback(GLFWwindow *window, int button, int action, int mods)
	{
		double posX, posY;

		if (action == GLFW_PRESS)
		{
			 glfwGetCursorPos(window, &posX, &posY);
			 //cout << "Pos X " << posX <<  " Pos Y " << posY << endl;
		}
	}

	void resizeCallback(GLFWwindow *window, int width, int height)
	{
		glViewport(0, 0, width, height);
	}

	void init(const std::string& resourceDirectory)
	{
		GLSL::checkVersion();

		ANIMATION_ANGLE = 0;

		// Set background color.
		glClearColor(.42f, .64f, .86f, 1.0f);
		// Enable z-buffer test.
		glEnable(GL_DEPTH_TEST);


		// Initialize the GLSL program.
		prog = make_shared<Program>();
		prog->setVerbose(true);
		prog->setShaderNames(resourceDirectory + "/simple_vert.glsl", resourceDirectory + "/simple_frag.glsl");
		prog->init();
		prog->addUniform("P");
		prog->addUniform("MV");
		//prog->addUniform("campos");
		prog->addAttribute("vertPos");
		prog->addAttribute("vertNor");

		groundProg = make_shared<Program>();
		groundProg->setVerbose(true);
		groundProg->setShaderNames(resourceDirectory + "/ground_vert.glsl", resourceDirectory + "/ground_frag.glsl");
		groundProg->init();
		groundProg->addUniform("P");
		groundProg->addUniform("MV");
		//prog->addUniform("campos");
		groundProg->addAttribute("vertPos");
		groundProg->addAttribute("vertNor");
	}

	void initGeom(const std::string& resourceDirectory)
	{
		// Initialize mesh.
		shape = make_shared<Shape>();
		shape->loadMesh(resourceDirectory + "/cube.obj");
		shape->resize();
		shape->init();

		circle = make_shared<Shape>();
		circle->loadMesh(resourceDirectory + "/bunny.obj");
		circle->resize();
		circle->init();

		for (int i = 0; i < PLAT_NUM; i++) {
			RANDOMS[i] = rand() % 6 * 4 - 12;
		}
		for (int i = 1; i < PLAT_NUM; i++) {
			GAPS[i] = rand() % 4 * GAP_WIDTH/2 + GAP_WIDTH/4;
		}
		//GAPS[0] = 0;
	}

	float min(float a, float b) {
		if (a < b) {
			return a;
		}
		return b;
	}

	int getPosition(float xpos, float ypos, vector<Position> p) {
		for (int i = 0; i < p.size(); i++) {
			if ((p[i].p1.x < xpos) && (p[i].p2.x > xpos) && (p[i].p2.y <= ypos)) {
				NEW_HEIGHT = p[i].p2.y;
				return i;
			}
		}
		return -1;
	}

	float terminalVelocity(float speed) {
		if (speed < 0) {
			if (speed < GRAVITY * -15) {
				return GRAVITY * -15;
			}
		}
		return speed;
	}

	bool isPrime(int num) {
		for (int i = 2; i < num / 2; ++i) {
			if (num % i == 0) {
				return false;
			}
		}
		return true;
	}

	void render()
	{
		// Get current frame buffer size.
		int width, height;
		glfwGetFramebufferSize(windowManager->getHandle(), &width, &height);
		glViewport(0, 0, width, height);

		//create array of 2D positions for collision detection
		vector<Position> positions(PLAT_NUM);
		float inc = 0;
		int gaps = 0;

		// Clear framebuffer.
		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

		//Use the matrix stack for Lab 6
		float aspect = width/(float)height;

		// Create the matrix stacks - please leave these alone for now
		auto P = make_shared<MatrixStack>();
		auto MV = make_shared<MatrixStack>();

		auto gP = make_shared<MatrixStack>();
		auto gMV = make_shared<MatrixStack>();
		// Apply perspective projection.
		P->pushMatrix();
		P->perspective(45.0f, aspect, 0.01f, 100.0f);

		gP->pushMatrix();
		gP->perspective(45.0f, aspect, 0.01f, 100.0f);

		// Draw a stack of cubes with indiviudal transforms
		prog->bind();
		glUniformMatrix4fv(prog->getUniform("P"), 1, GL_FALSE, value_ptr(P->topMatrix()));
		vec3 cameraPosition = vec3(0, Y_HEIGHT, CAMERA);
		

		/*
		---------------------------------------------------------
		------------------------PLAYER MODEL---------------------
		---------------------------------------------------------
		*/
		MV->pushMatrix();
			//body
			MV->loadIdentity();
			MV->translate(vec3(0, -Y_HEIGHT + Y_DIR - PLAT_HEIGHT, CAMERA + Z_DIR));
			MV->rotate(DIRECTION, vec3(0.0, 1.0, 0.0));
			//head
			MV->pushMatrix();
				MV->translate(vec3(0.0, 2, 0.0));
				MV->scale(vec3(0.75, 0.75, 0.75));
				MV->translate(vec3(0.0, -0.5, 0.0));
				glUniformMatrix4fv(prog->getUniform("MV"), 1, GL_FALSE, value_ptr(MV->topMatrix()));
				shape->draw(prog);
			MV->popMatrix();
			//front arm
			MV->pushMatrix();
				MV->translate(vec3(0.0, 0.5, 1.25));
				MV->rotate(ANIMATION_ANGLE + ARM_ANGLE, vec3(0.0, 0.0, 1.0));
				MV->translate(vec3(0.0, -1.0, 0.0));
				MV->scale(vec3(0.25, 0.75, 0.25));
				glUniformMatrix4fv(prog->getUniform("MV"), 1, GL_FALSE, value_ptr(MV->topMatrix()));
				shape->draw(prog);
			MV->popMatrix();
			//back arm
			MV->pushMatrix();
				MV->translate(vec3(0.0, 0.5, -1.25));
				MV->rotate(-ANIMATION_ANGLE, vec3(0.0, 0.0, 1.0));
				MV->translate(vec3(0.0, -1.0, 0.0));
				MV->scale(vec3(0.25, 0.75, 0.25));
				glUniformMatrix4fv(prog->getUniform("MV"), 1, GL_FALSE, value_ptr(MV->topMatrix()));
				shape->draw(prog);
			MV->popMatrix();
			//front leg
			MV->pushMatrix();
				MV->translate(vec3(0.0, -1, 0.6));
				MV->rotate(-ANIMATION_ANGLE, vec3(0.0, 0.0, 1.0));
				MV->translate(vec3(0.0, -1.0, 0.0));
				MV->scale(vec3(0.4, 1, 0.4));
				glUniformMatrix4fv(prog->getUniform("MV"), 1, GL_FALSE, value_ptr(MV->topMatrix()));
				shape->draw(prog);
			MV->popMatrix();
			//back leg
			MV->pushMatrix();
				MV->translate(vec3(0.0, -1, -0.6));
				MV->rotate(ANIMATION_ANGLE, vec3(0.0, 0.0, 1.0));
				MV->translate(vec3(0.0, -1.0, 0.0));
				MV->scale(vec3(0.4, 1, 0.4));
				glUniformMatrix4fv(prog->getUniform("MV"), 1, GL_FALSE, value_ptr(MV->topMatrix()));
				shape->draw(prog);
			MV->popMatrix();
			glUniformMatrix4fv(prog->getUniform("MV"), 1, GL_FALSE, value_ptr(MV->topMatrix()));
			shape->draw(prog);
		MV->popMatrix();
		prog->unbind();
		/*
		---------------------------------------------------------
		---------------------PLATFORM GENERATION-----------------
		---------------------------------------------------------
		*/
		groundProg->bind();
		glUniformMatrix4fv(groundProg->getUniform("P"), 1, GL_FALSE, value_ptr(gP->topMatrix()));
		MV->loadIdentity();
		for (int i = 0; i < positions.size(); i++) {
			int gap = GAPS[i];
			gaps += gap;
			positions[i].p1.x = STAGE + i * 100 + i * gaps / (i+1);// (GAP_WIDTH + 100);
			positions[i].p1.y = inc - 30;
			positions[i].p2.x = STAGE + (i + 1) * 100 + i * gaps / (i+1);
			int random = RANDOMS[i];
			//cout << random << endl;
			positions[i].p2.y = inc;
			MV->pushMatrix();
				MV->translate(vec3(-X_DIR + GROUND / 2 + i * 100 + i * gaps/(i+1)/*(100 + GAP_WIDTH)*/, -Y_HEIGHT - PLAYER_HEIGHT + inc - PLAT_HEIGHT, CAMERA + Z_DIR));
				MV->scale(vec3(GROUND, EARTH_SCALE, 2.5));
				glUniformMatrix4fv(prog->getUniform("MV"), 1, GL_FALSE, value_ptr(MV->topMatrix()));
				shape->draw(groundProg);
			MV->popMatrix();
			inc += random;
		}
		
		groundProg->unbind();

		// Pop matrix stacks.
		P->popMatrix();

		// update shoulder angle - animate
		if ((LEFT || RIGHT) && !JUMP) {
			if (ANIMATION_ANGLE > 0.7 || ANIMATION_ANGLE < -0.7)
			{
				ANIMATION_DIRECTION = !ANIMATION_DIRECTION;
			}
			if (ANIMATION_DIRECTION) {
				ANIMATION_ANGLE -= 0.01 * SPEED;
			}
			else {
				ANIMATION_ANGLE += 0.01 * SPEED;
			}
		}
		if (JUMP) {
			ARM_ANGLE = 2.25 - ANIMATION_ANGLE;
		}
		else {
			ARM_ANGLE = 0;
		}


		/*
		---------------------------------------------------------
		---------------------COLLISION TESTING-------------------
		---------------------------------------------------------
		*/
		//checks to see if the character is jumping or not
		//if it is, then the jump is executed until it gets back to platform level
		//if not, it increments the velocity due to falling
		int p = getPosition(X_DIR, Y_DIR, positions);
		int n;
		if (JUMP && GROUNDED) {
			Y_DIR += JUMP_VELOCITY;
			JUMP_VELOCITY -= GRAVITY;
			JUMP_VELOCITY = terminalVelocity(JUMP_VELOCITY);
			if ((p == -1)) {
				n = NEXT_PLAT;
			}
			else {
				n = p;
			}
			if ((floor(Y_DIR) == positions[n].p2.y) && p >= 0) {
				Y_DIR = positions[n].p2.y;
				JUMP = false;
				JUMP_VELOCITY = JUMP_STRENGTH;
				GROUNDED = true;
			}
			if (Y_DIR < positions[n].p1.y) {
				X_DIR = 0;
				Y_DIR = 0;
				JUMP_VELOCITY = JUMP_STRENGTH;
				GROUNDED = true;
				JUMP = false;
			}
		}
		else {
			if (p < 0) {
				JUMP = false;
				GROUNDED = false;
				Y_DIR += FALL_VELOCITY;
				FALL_VELOCITY -= GRAVITY;
				FALL_VELOCITY = terminalVelocity(FALL_VELOCITY);
				if ((p == -1)) {
					n = NEXT_PLAT;
				}
				else {
					n = p;
				}
				if ((floor(Y_DIR) == positions[n].p2.y) && p >= 0) {
					Y_DIR = positions[n].p2.y;
				}
				if (Y_DIR < positions[n].p1.y) {
					X_DIR = 0;
					Y_DIR = 0;
					JUMP_VELOCITY = JUMP_STRENGTH;
					GROUNDED = true;
					JUMP = false;
				}
			}
			else {
				if ((p == -1)) {
					n = NEXT_PLAT;
				}
				else {
					n = p;
				}
				if (round(Y_DIR) > positions[n].p2.y) {
					Y_DIR += FALL_VELOCITY;
					FALL_VELOCITY -= GRAVITY;
					FALL_VELOCITY = terminalVelocity(FALL_VELOCITY);
				}
				if (round(Y_DIR) == positions[n].p2.y) {
					Y_DIR = positions[n].p2.y;
					FALL_VELOCITY = -GRAVITY;
					GROUNDED = true;
				}
			}
		}
		if (p >= 0 && Y_DIR == positions[p].p2.y) {
			FALL_VELOCITY = -GRAVITY;
			NEXT_PLAT = p + 1;
			GROUNDED = true;
			if (PLAT_HEIGHT < NEW_HEIGHT) {
				PLAT_HEIGHT += CAM_ANIM;
			}
			if (PLAT_HEIGHT > NEW_HEIGHT) {
				PLAT_HEIGHT -= CAM_ANIM;
			}
		}


		/*
		---------------------------------------------------------
		-------------------------MOVEMENT------------------------
		---------------------------------------------------------
		*/
		//turns the character around if going left
		if (LEFT) {
			X_DIR -= 0.05 * SPEED;
			if (DIRECTION < PI) {
				DIRECTION = min(DIRECTION + ROTATION_INCREMENT, PI);
			}
		}
		//turns the character around if going right
		if (RIGHT) {
			X_DIR += 0.05 * SPEED;
			if (DIRECTION > 0) {
				DIRECTION = -min(-(DIRECTION - ROTATION_INCREMENT), 0);
			}
		}	

		//running
		if (RUNNING) {
			if (SPEED < RUN_SPEED) {
				SPEED += 1;
			}
		}
		else {
			if (SPEED > WALK_SPEED) {
				SPEED -= 1;
			}
		}
	}
};

int main(int argc, char *argv[])
{
	// Where the resources are loaded from
	std::string resourceDir = "../resources";
	//environment variables
	float WINDOW_HEIGHT = 500;
	float WINDOW_WIDTH = 1500;

	if (argc >= 2)
	{
		resourceDir = argv[1];
	}

	Application *application = new Application();

	// Your main will always include a similar set up to establish your window
	// and GL context, etc.

	WindowManager *windowManager = new WindowManager();
	windowManager->init(WINDOW_WIDTH, WINDOW_HEIGHT);
	windowManager->setEventCallbacks(application);
	application->windowManager = windowManager;

	// This is the code that will likely change program to program as you
	// may need to initialize or set up different data and state

	application->init(resourceDir);
	application->initGeom(resourceDir);

	// Loop until the user closes the window.
	while (! glfwWindowShouldClose(windowManager->getHandle()))
	{
		// Render scene.
		application->render();

		// Swap front and back buffers.
		glfwSwapBuffers(windowManager->getHandle());
		// Poll for and process events.
		glfwPollEvents();
	}

	// Quit program.
	windowManager->shutdown();
	return 0;
}
